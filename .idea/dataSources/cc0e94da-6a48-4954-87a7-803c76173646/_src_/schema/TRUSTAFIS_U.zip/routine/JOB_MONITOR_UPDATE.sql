CREATE PROCEDURE             JOB_MONITOR_UPDATE
AS
    CUR_CPU NUMBER;
    CUR_MEM NUMBER;
    CUR_DISK NUMBER;
    PREV_CPU_1 NUMBER;
    PREV_MEM_1 NUMBER;
    PREV_DISK_1 NUMBER;
    PREV_CPU_2 NUMBER;
    PREV_MEM_2 NUMBER;
    PREV_DISK_2 NUMBER;
    
    LICENSE_STATE NUMBER;
    FINAL_STRING VARCHAR2(255);
    
    MEM_LEVEL NUMBER;
    DISK_LEVEL NUMBER;
    CPU_LEVEL NUMBER;

    MEM_LEVEL_2 NUMBER;
    DISK_LEVEL_2 NUMBER;
    CPU_LEVEL_2 NUMBER;
    
BEGIN

    MEM_LEVEL_2 :=100;
    DISK_LEVEL_2 :=100;
    CPU_LEVEL_2 :=100;
    

    SELECT VALUE INTO DISK_LEVEL
      FROM TAS_SYS_SETTING
     WHERE APP_ID = 'TrustAFIS'
           AND  SUB_KEY = 'HD_USE_PERCENT_WARN_GOAL';

    SELECT VALUE INTO MEM_LEVEL
      FROM TAS_SYS_SETTING
     WHERE APP_ID = 'TrustAFIS'
           AND  SUB_KEY = 'RAM_USE_PERCENT_WARN_GOAL';

    SELECT VALUE INTO CPU_LEVEL
      FROM TAS_SYS_SETTING
     WHERE APP_ID = 'TrustAFIS'
           AND  SUB_KEY = 'CPU_USE_PERCENT_WARN_GOAL';
           

    FOR SERVER IN (SELECT ENGINE_CLUSTER_CODE, ENGINE_SERVER_CODE FROM TAS_MON_ENV_STATISTIC)
    LOOP 
    
            SELECT  NVL(TOTAL_VALUE,0) INTO LICENSE_STATE
        FROM DUAL LEFT JOIN (SELECT SERVICE_KEY, TOTAL_VALUE, CREATE_DATE 
                FROM TAS_MON_SERVICE_STATISTIC
                WHERE SERVICE_KEY = 8 AND ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                ORDER BY CREATE_DATE DESC) T
                ON 1 = 1
        WHERE ROWNUM <= 1;
    

        SELECT NVL(TOTAL_VALUE,0) INTO CUR_CPU
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 4
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 1;   
           

        SELECT NVL(TOTAL_VALUE,0) INTO CUR_MEM
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 5
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 1;   

        SELECT NVL(TOTAL_VALUE,0) INTO CUR_DISK
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 6
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 1;   

        SELECT NVL(TOTAL_VALUE,0) INTO PREV_CPU_1
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 4
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 2;              
           

        SELECT NVL(TOTAL_VALUE,0) INTO PREV_MEM_1
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 5
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 2;              

        SELECT NVL(TOTAL_VALUE,0) INTO PREV_DISK_1
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 6
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 2;              


        SELECT NVL(TOTAL_VALUE,0) INTO PREV_CPU_2
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 4
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1
           WHERE NO = 3;                               
           

        SELECT NVL(TOTAL_VALUE,0) INTO PREV_MEM_2
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 5
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1                       
           WHERE NO = 3;                              

        SELECT NVL(TOTAL_VALUE,0) INTO PREV_DISK_2
            FROM DUAL LEFT JOIN 

                (SELECT TOTAL_VALUE ,rownum NO, CREATE_DATE 
                FROM (SELECT TOTAL_VALUE , CREATE_DATE
                        FROM TAS_MON_SERVICE_STATISTIC
                       WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                            AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE 
                            AND SERVICE_KEY = 6
                       ORDER BY CREATE_DATE desc))
            ON 1 = 1                       
           WHERE NO = 3;                  
           
        IF((PREV_CPU_2 < CPU_LEVEL AND  PREV_MEM_2 < MEM_LEVEL AND PREV_DISK_2 < DISK_LEVEL)
            AND (PREV_CPU_1 < CPU_LEVEL AND  PREV_MEM_1 < MEM_LEVEL AND PREV_DISK_1 < DISK_LEVEL)
            AND (CUR_CPU < CPU_LEVEL AND  CUR_MEM < MEM_LEVEL AND CUR_DISK < DISK_LEVEL))
        THEN
            UPDATE  TAS_MON_ENV_STATISTIC 
                SET ENGINE_WORKSTATION_STATUS = 0
                WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                    AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE; 
        
        ELSIF((PREV_CPU_2 > CPU_LEVEL_2 OR  PREV_MEM_2 > MEM_LEVEL_2 OR PREV_DISK_2 > DISK_LEVEL_2)
            OR (PREV_CPU_1 > CPU_LEVEL_2 OR  PREV_MEM_1 > MEM_LEVEL_2 OR PREV_DISK_1 > DISK_LEVEL_2)
            OR (CUR_CPU > CPU_LEVEL_2 OR  CUR_MEM > MEM_LEVEL_2 OR CUR_DISK > DISK_LEVEL_2))
        THEN
            UPDATE  TAS_MON_ENV_STATISTIC 
                SET ENGINE_WORKSTATION_STATUS = 2
                WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                    AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE; 
                    
        ELSE 
		
            UPDATE  TAS_MON_ENV_STATISTIC 
                SET ENGINE_WORKSTATION_STATUS = ENGINE_WORKSTATION_STATUS
                WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                    AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE; 
					
        END IF;

        ---UPDATE LICENSE STATUS
        SELECT  NVL(TOTAL_VALUE,0) INTO LICENSE_STATE
        FROM DUAL LEFT JOIN (SELECT SERVICE_KEY, TOTAL_VALUE, CREATE_DATE 
                FROM TAS_MON_SERVICE_STATISTIC
                WHERE SERVICE_KEY = 8 AND ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                ORDER BY CREATE_DATE DESC) T
                ON 1 = 1
        WHERE ROWNUM <= 1;

        FINAL_STRING :='';
        IF( (PREV_CPU_2 > CPU_LEVEL AND PREV_CPU_2 < CPU_LEVEL_2)
            AND (PREV_CPU_1 > CPU_LEVEL AND PREV_CPU_1 < CPU_LEVEL_2)
            AND (CUR_CPU > CPU_LEVEL AND CUR_CPU < CPU_LEVEL_2))
        THEN 
            IF( FINAL_STRING IS NULL)  
            THEN 
                FINAL_STRING := FINAL_STRING || '3';
            ELSE 
                FINAL_STRING := FINAL_STRING || ',3';
            END IF;
        END IF;        

        dbms_output.put_line('1   PREV_MEM_2 ' || PREV_MEM_2 || ' PREV_MEM_1 ' || PREV_MEM_1 || ' CUR_MEM ' ||  CUR_MEM || 'FINAL_STRING' || FINAL_STRING);
        IF( (PREV_MEM_2 > MEM_LEVEL AND PREV_MEM_2 < MEM_LEVEL_2)
            AND (PREV_MEM_1 > MEM_LEVEL AND PREV_MEM_1 < MEM_LEVEL_2)
            AND (CUR_MEM > MEM_LEVEL AND CUR_MEM < MEM_LEVEL_2))
        THEN 
            --dbms_output.put_line('2   PREV_MEM_2 ' || PREV_MEM_2 || ' PREV_MEM_1 ' || PREV_MEM_1 || ' CUR_MEM ' ||  CUR_MEM || 'FINAL_STRING' || FINAL_STRING);
            IF( FINAL_STRING IS NULL) 
            THEN
                FINAL_STRING := FINAL_STRING || '2';
            ELSE
                FINAL_STRING := FINAL_STRING || ',2';
            END IF;
        END IF;        


        IF( (PREV_DISK_2 > DISK_LEVEL AND PREV_DISK_2 < DISK_LEVEL_2)
            AND (PREV_DISK_1 > DISK_LEVEL AND PREV_DISK_1 < DISK_LEVEL_2)
            AND (CUR_DISK > DISK_LEVEL AND CUR_DISK < DISK_LEVEL_2))
        THEN 

            IF( FINAL_STRING IS NULL) 
            THEN 

                FINAL_STRING := FINAL_STRING || '1';
            ELSE 

                FINAL_STRING := FINAL_STRING || ',1';
            END IF;
        END IF;        

        IF (LICENSE_STATE <> 0)
        THEN 

            IF( FINAL_STRING IS NULL) 
            THEN 

                FINAL_STRING := FINAL_STRING || '4';
            ELSE 

                FINAL_STRING := FINAL_STRING || ',4';
            END IF;
        END IF;        
		--dbms_output.put_line('FINAL_ ' || FINAL_STRING || 'LICENSE_STATE ' || LICENSE_STATE);

        UPDATE  TAS_MON_ENV_STATISTIC 
            SET ENGINE_WARN_FIELD = FINAL_STRING
            WHERE ENGINE_CLUSTER_CODE = SERVER.ENGINE_CLUSTER_CODE 
                AND ENGINE_SERVER_CODE = SERVER.ENGINE_SERVER_CODE; 

    END LOOP;
    
END;
/
