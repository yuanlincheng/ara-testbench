CREATE PROCEDURE             JOB_INIT
AS
   job1 NUMBER;
   job2 NUMBER;
   job3 NUMBER;
   job_exists NUMBER;
BEGIN
	dbms_job.submit(job1, 'JOB_MONITOR_UPDATE;', SYSDATE, 'sysdate+30/86400');
	dbms_job.run(job1);--和select * from user_jobs; 中的job值对应，看what对应的过程
	
	dbms_job.submit(job2, 'JOB_CLEAN_MONITOR_DATA;', SYSDATE, 'sysdate+30/86400');
	dbms_job.run(job2);
	
	dbms_job.submit(job3, 'JOB_MONITOR_UPDATE_NETWORK;', SYSDATE, 'sysdate+30/86400');
	dbms_job.run(job3);	
END;
/
