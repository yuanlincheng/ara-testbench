CREATE PACKAGE             aff_img IS
    --这个包：包含两个函数，一个存储过程
    --这两个函数不直接调用，而是由存储过程间接调用
    FUNCTION    time_spend(timeBefore varchar2, format  varchar2:='YYYY-MM-DD HH24:MI:SS') RETURN  INTEGER;
    FUNCTION    time_spend(timeBefore varchar2, timeAfter  varchar2, format  varchar2:='YYYY-MM-DD HH24:MI:SS') RETURN  INTEGER;

    --PROCEDURE   ids_get(BLOCK_NUM IN INTEGER, IDS OUT VARCHAR, format IN VARCHAR:= 'YYYY-MM-DD HH24:MI:SS');
    PROCEDURE ids_get(BLOCK_NUM IN INTEGER, IDS OUT VARCHAR2, flagNo IN VARCHAR2 DEFAULT 'N', flagProcess IN VARCHAR2 DEFAULT 'P', format IN VARCHAR2  DEFAULT 'YYYY-MM-DD HH24:MI:SS');

END aff_img;
/
