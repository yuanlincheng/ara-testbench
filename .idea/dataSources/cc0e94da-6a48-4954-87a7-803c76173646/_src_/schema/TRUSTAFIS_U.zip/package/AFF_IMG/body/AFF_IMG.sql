CREATE PACKAGE BODY             aff_img IS
    --时间函数1，参数和当前时间比较
    FUNCTION    time_spend(timeBefore varchar2, format  varchar2:='YYYY-MM-DD HH24:MI:SS') RETURN  INTEGER IS
    timeCurrent   varchar2(100);
    stampBefore    timestamp;
    stampCurrent  timestamp;
    spend  INTEGER;
    BEGIN
        timeCurrent := to_char(sysdate, format);
        
        
        stampBefore := to_timestamp(timeBefore, format);
        stampCurrent := to_timestamp(timeCurrent, format);
        
        
        spend := extract(day from stampCurrent - stampBefore) * 24 * 60 * 60 + 
                    extract(hour from stampCurrent - stampBefore) * 60 * 60  + 
                        extract(minute from  stampCurrent  - stampBefore) * 60 +
                            extract(second from  stampCurrent  - stampBefore);
                            
        RETURN spend;
    END time_spend;
    

    ---时间函数2，参数和当前时间比较
    FUNCTION    time_spend(timeBefore varchar2, timeAfter  varchar2, format  varchar2:='YYYY-MM-DD HH24:MI:SS') RETURN  INTEGER  IS
    stampBefore     timestamp;
    stampAfter      timestamp;
    spend  INTEGER;
    BEGIN
        stampBefore := to_timestamp(timeBefore, format);
        stampAfter := to_timestamp(timeAfter, format);   

        spend :=extract(day from  stampAfter - stampBefore) * 24 * 60 * 60 + 
                     extract(hour from stampAfter - stampBefore) * 60 * 60  + 
                        extract(minute from  stampAfter  - stampBefore) * 60 +
                            extract(second from  stampAfter  - stampBefore);    
        RETURN spend;
    END time_spend;



    --存储过程，获取指定个数的ID
    PROCEDURE  ids_get(BLOCK_NUM IN INTEGER, IDS OUT VARCHAR2, flagNo IN VARCHAR2 DEFAULT 'N', flagProcess IN VARCHAR2 DEFAULT 'P', format IN VARCHAR2:= 'YYYY-MM-DD HH24:MI:SS')  IS
    --IT  INTEGER:=1;
    BEGIN
        IDS := ' ';
        --1：仅仅锁定自己需要的行,而不锁住整个表 
        FOR ITE_ID IN  (SELECT  IMG_FINGER_ID_POSITION FROM TAS_IMPORT_IMG 
                 WHERE 
                       ( IMG_READ_FLAG = flagNo 
                         OR 
                            (IMG_READ_FLAG = flagProcess AND time_spend(IMG_CREATE_DATE) > 1800  )) 
                      AND  
                        ROWNUM <= BLOCK_NUM  for update ) 
        LOOP
        
            IDS := IDS || ',' || ITE_ID.IMG_FINGER_ID_POSITION;
        END LOOP;
        
        --2：在当前会话中更新选中的行
        UPDATE TAS_IMPORT_IMG SET  IMG_READ_FLAG = flagProcess, IMG_CREATE_DATE = to_char(sysdate, format) 
             WHERE  ( IMG_READ_FLAG = flagNo OR  (IMG_READ_FLAG = flagProcess AND time_spend(IMG_CREATE_DATE) > 1800  )  ) 
                AND  
                    ROWNUM <= BLOCK_NUM ;
        
        --3：提交
        COMMIT;
    END ids_get;

END  aff_img;
/
